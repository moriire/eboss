<template>
      <section class="slider_section classic_ecommerce_slider position-relative clearfix">
        <div class="main_slider clearfix" data-slick='{"arrows": false}'>
          <div class="item d-flex align-items-center clearfix" data-background="//assets/images/slider/classic_ecommerce/bg_01.jpg">
            <div class="container">
              <div class="slider_content">
                <h3 data-animation="fadeInUp" data-delay=".6s">Sweet Home Collection.</h3>
                <p data-animation="fadeInUp" data-delay=".8s">
                  Discover new ways to dress this spring with a selection of the best designer jackets.
                </p>
                <div class="abtn_wrap clearfix" data-animation="fadeInUp" data-delay="1s">
                  <a href="#!" class="custom_btn bg_white text-uppercase">Collection</a>
                </div>
              </div>
            </div>
          </div>

          <div class="item d-flex align-items-center clearfix" data-background="/assets/images/slider/classic_ecommerce/bg_01.jpg">
            <div class="container">
              <div class="slider_content">
                <h3 data-animation="fadeInUp" data-delay=".6s">Sweet Home Collection.</h3>
                <p data-animation="fadeInUp" data-delay=".8s">
                  Discover new ways to dress this spring with a selection of the best designer jackets.
                </p>
                <div class="abtn_wrap clearfix" data-animation="fadeInUp" data-delay="1s">
                  <a href="#!" class="custom_btn bg_white text-uppercase">Collection</a>
                </div>
              </div>
            </div>
          </div>

          <div class="item d-flex align-items-center clearfix" data-background="/assets/images/slider/classic_ecommerce/bg_01.jpg">
            <div class="container">
              <div class="slider_content">
                <h3 data-animation="fadeInUp" data-delay=".6s">Sweet Home Collection.</h3>
                <p data-animation="fadeInUp" data-delay=".8s">
                  Discover new ways to dress this spring with a selection of the best designer jackets.
                </p>
                <div class="abtn_wrap clearfix" data-animation="fadeInUp" data-delay="1s">
                  <a href="#!" class="custom_btn bg_white text-uppercase">Collection</a>
                </div>
              </div>
            </div>
          </div>

          <div class="item d-flex align-items-center clearfix" data-background="/assets/images/slider/classic_ecommerce/bg_01.jpg">
            <div class="container">
              <div class="slider_content">
                <h3 data-animation="fadeInUp" data-delay=".6s">Sweet Home Collection.</h3>
                <p data-animation="fadeInUp" data-delay=".8s">
                  Discover new ways to dress this spring with a selection of the best designer jackets.
                </p>
                <div class="abtn_wrap clearfix" data-animation="fadeInUp" data-delay="1s">
                  <a href="#!" class="custom_btn bg_white text-uppercase">Collection</a>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- slider progress -->
        <div class="slick-progress">
          <span></span>
        </div>
      </section>

<!--HelloWorld msg="hello mother fucker"/-->
</template>

<script>
export default {
  name: 'HelloWorld',
  props: {
    msg: String
  }
}
</script>