<script>
</script>
<style src="../public/fonts/fontawesome/css/font-awesome.min.css"></style>
<style src="../public/fonts/ionicons/css/ionicons.min.css"></style>
<style src="../public/css/fancybox.min.css"></style>
<style src="../public/css/jquery.timepicker.css"></style>
<style src="../public/css/bootstrap-datepicker.css"></style>
<style src="../public/css/aos.css"></style>
<style src="../public/css/animate.css"></style>
<style src="../public/css/bootstrap.min.css"></style>
<style src="../public/css/style.css"></style>
<template>
  <router-view></router-view>
</template>
