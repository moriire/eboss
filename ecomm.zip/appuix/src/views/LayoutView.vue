<template>
	<router-view />
</template>

<script>
// @ is an alias to /src
//import axios from "axios"
//axios.defaults.xsrfCookieName = 'csrftoken';
//axios.defaults.xsrfHeaderName = 'X-CSRFToken';
//const headers = {'Content-Type': 'application/json', 'X-CSRFToken': 'csrftoken',};

export default {
  name: 'LayoutView',
}
</script>
